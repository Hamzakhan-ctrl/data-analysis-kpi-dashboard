# Maincrafts — Data Analytics & Business Intelligence Task 2

## Project
**Advanced Data Analysis, SQL Joins & Business KPI Dashboard**

This repository contains a complete submission package for Task 2. The task requires:
- SQL JOINs and business aggregations
- KPI calculations
- comparative analysis
- Excel analysis with pivot-style summaries and calculated KPI examples
- a professional KPI dashboard
- business performance reporting

The task document specifies Orders and Customers as the core related datasets and asks for KPIs such as Total Sales, Total Profit, Profit Margin and Total Customers, plus regional/category/monthly/customer/segment analysis.

## Dataset
The submission uses a **synthetic dataset** created for this project because no raw Orders/Customers dataset was supplied with the task instructions.

- `data/orders.csv` — 900 orders
- `data/customers.csv` — 120 customers

## Deliverables

| File | Purpose |
|---|---|
| `maincrafts_task2.sql` | Table definitions + SQL JOINs, aggregations and business queries |
| `Maincrafts_Task2_Excel_Analysis.xlsx` | Orders, Customers, KPI analysis, calculated-column examples and dashboard |
| `dashboard.html` | Interactive browser-based KPI dashboard |
| `screenshots/business_kpi_dashboard.png` | Dashboard screenshot for submission |
| `Business_Performance_Report.pdf` | 2–3 page business summary report |
| `data/orders.csv` | Orders dataset |
| `data/customers.csv` | Customers dataset |

## Key KPIs
- Total Sales: **$1,030,154.49**
- Total Profit: **$137,981.18**
- Profit Margin: **13.39%**
- Total Customers: **120**
- Total Orders: **900**
- Average Order Value: **$1,144.62**

## Main Business Findings
1. **Highest revenue region:** North — $317,453
2. **Highest profit-margin category:** Office Supplies — 19.2%
3. **Most valuable customer segment by sales:** Consumer — $535,978
4. **Discounting:** profitability varies by discount level; monitor margin instead of relying only on revenue growth.
5. **Seasonality:** monthly sales show recurring variation, supporting monthly trend monitoring.

## SQL
Open `maincrafts_task2.sql` in MySQL 8+ or another compatible SQL environment.

1. Create the `Customers` and `Orders` tables.
2. Import the two CSV files.
3. Run the JOIN and KPI queries in the script.

## Excel
Open `Maincrafts_Task2_Excel_Analysis.xlsx`.

Sheets:
- `Orders`
- `Customers`
- `KPI_Analysis`
- `Formula_Examples`
- `Dashboard`

The workbook includes pivot-style summary tables, KPI calculations, formulas such as IF/SUMIFS/COUNTIFS examples, and charts.

## Dashboard
`dashboard.html` is a browser-based interactive presentation of the KPI analysis. It can be hosted with GitHub Pages.

The PNG dashboard in `screenshots/` can be uploaded as the required dashboard screenshot.

### Power BI / Tableau note
A native `.pbix` or `.twb` file requires the corresponding desktop authoring application. This submission therefore includes a **BI-ready data model, SQL, Excel dashboard, interactive HTML dashboard, and screenshot**, which can be imported into Power BI or Tableau if a native workbook is required by your evaluator.

## Suggested GitHub repository structure

```text
maincrafts-task2/
├── data/
│   ├── customers.csv
│   └── orders.csv
├── screenshots/
│   └── business_kpi_dashboard.png
├── maincrafts_task2.sql
├── Maincrafts_Task2_Excel_Analysis.xlsx
├── dashboard.html
├── Business_Performance_Report.pdf
└── README.md
```
